var util = require('../../utils/util.js')
const app = getApp()
// pages/insert/insert.js
const db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    content: "",
    contentdetail: "",
    receiverId: "公开",
    time: "",
    hiddenName: true, //true,代表公开发送
    nickName: "",
    avatar: "",
    LetterBoxCode: null,
    ContentDetailValue: "",
    LetterBoxCodeValue: "",
    noteNowLen: 0 //当前输入的信封文字书
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    console.log(app.globalData.ShowImage)
    var that = this
    wx.cloud.callFunction({
      name: 'login',
      complete: res => {
        that.setData({
          _openid: res.result.openid,
        })
      }
    })


  },
  /**
   * Hide和Show用来控制收信人id输入框的显示与否
   */
  Hide: function () {
    this.setData({
      hiddenName: true,
      receiverId: "公开"
    })
  },
  Show: function () {
    this.setData({
      hiddenName: false,
      receiverId: ""
    })
  },

  /**
   * 发送信件
   */
  SendLetter: function () {
    var that = this
    if (that.data.contentdetail == "") {
      wx.showToast({
        icon: 'none',
        title: '信件内容不可为空'
      })
    }else{
      if (that.data.hiddenName) {
        that.onAdd("公开")
      } else {
        console.log()
        if (that.data.LetterBoxCode == "") {
          wx.showToast({
            icon: 'none',
            title: '信箱编码不可为空'
          })
        } else {
          that.onQuery()
        }
  
      }
    }
    

  },

  //查询收信人是否存在
  onQuery: function () {
    var that = this;
    const db = wx.cloud.database()

    db.collection('User').where({

      LetterBoxCode: that.data.LetterBoxCode
    }).get({
      success: res => {
        if (res.data.length == 0) {
          wx.showToast({
            icon: 'none',
            title: '邮箱编码不存在'
          })
        } else {
          //注意不要写成res.data._openid
          that.onAdd(res.data[0]._openid)
        }
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '邮箱编码查询失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
      }
    })
  },

  /**
   * 
   * @param {用户的唯一标识} _openid 
   */
  onAdd: function (_openid) {
    var that = this;
    wx.getUserInfo({
      complete: (res) => {
        that.setData({
          nickName: res.userInfo.nickName,
          avatar: res.userInfo.avatarUrl,
          time: util.formatTime(new Date())
        })
        var DBNA = [] //数据库名称数组        
        if (_openid == "公开") {
          DBNA = ['Send', 'Letter']
        } else {
          DBNA = ['Send', 'Receive']
        }
        console.log(DBNA)
        DBNA.forEach(element => {
          db.collection(element).add({
            data: {
              //openid字段自动增加， 为保留字段，尚不清楚原因
              receiverId: _openid,
              LetterBoxCode: that.data.LetterBoxCode,
              content: that.data.contentdetail.substring(0, 10),
              contentdetail: that.data.contentdetail,
              time: that.data.time,
              like: false,
              collect: 0,
              reading: 0,
              nickName: that.data.nickName,
              avatar: that.data.avatar,
              comments: [],
            },
            success: res => {

              wx.showToast({
                title: '发送成功',
              })
              console.log(element + '[新增记录] 成功，记录 _id: ', res._id)
              that.onShow()
            },
            fail: err => {
              wx.showToast({
                icon: 'none',
                title: '发送失败'
              })
              console.error(element + '[新增记录] s失败: ', err)
            }
          })
        });
      },
    })



  },






  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this
    that.setData({
      ContentDetailValue: '',
      LetterBoxCodeValue: '',
      contentdetail: "",
      LetterBoxCode: "",
      noteNowLen: 0
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  //用于私发时填入收信人id
  LetterBoxCodeInput: function (e) {
    this.setData({
      LetterBoxCode: e.detail.value
    })

  },
  content: function (e) {
    this.setData({
      contentdetail: e.detail.value,
      noteNowLen: parseInt(e.detail.value.length)
    })


  },

})