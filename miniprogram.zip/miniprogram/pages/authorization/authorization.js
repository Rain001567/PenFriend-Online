// miniprogram/pages/authorization.js
const app = getApp()
const db = wx.cloud.database()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    //判断小程序的API，回调，参数，组件等是否在当前版本可用。
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    LetterBoxCode: "",
    _openid: "",
    checked: false, //false代表信箱编码尚未经过合法性检查
 //   expire:null,  //0 未授权，1已授权但过期  2 已授权且未过期代表授权未过期或者未授权
    show:false
  },
  
  /**
   * 
   * @param {页面加载函数} options 
   */
  onLoad: function (options) {
    var that = this
    // 查看是否授权
    wx.getSetting({
      success(res) {
        if (res.authSetting['scope.userInfo']) {
          wx.switchTab({
            url: '/pages/home/home',
          })
        }else{
          wx.cloud.callFunction({
            name: 'login',
            complete: res => {
              that.setData({
                _openid: res.result.openid,
              })
              db.collection('User').where({
                _openid:that.data._openid
              }).get({
                success: res => {
                  if(res.data.length !=0){
                    that.setData({
                      expire:1,
                      show:true
                    })  
                    wx.showToast({
                      title: '你的授权信息已过期，请重新授权',
                      icon:"none",
                      success: function () {
                        setTimeout(function () {
                          
                        }, 2000);
                      }
                    })
                  }else{
                    that.setData({
                      show:true,
                      expire:0
                    })
                  }
                },
                fail: err => {
      
                  wx.showToast({
                    icon: 'none',
                    title: '用户表查询失败'
                  })
                  that.setData({
                    show:true
                  })
                }
              })        
            }
          })
        }

      }
    })
  },

  /**
   * 用户点击了允许，注册账号并登录
   * @param {}} e 
   */
  bindGetUserInfo: function (e) {
    var that = this
    if (e.detail.userInfo) {
      if(e.currentTarget.id == 1){
        wx.switchTab({
          url: '/pages/home/home',
        })
      }else{
        db.collection('User').add({
          data: {
            avatarUrl: e.detail.userInfo.avatarUrl,
            city: e.detail.userInfo.city,
            country: e.detail.userInfo.country,
            gender: e.detail.userInfo.gender,
            language: e.detail.userInfo.language,
            nickName: e.detail.userInfo.nickName,
            province: e.detail.userInfo.province,
            LetterBoxCode: that.data.LetterBoxCode
          },
          success: res => {
            console.log('注册成功')
            wx.showToast({
              title: '注册成功',
              success: function () {
                setTimeout(function () {
                  wx.switchTab({
                    url: '/pages/home/home',
                  })
                }, 2000);
              }
            })
           
          },
          fail: err => {
            wx.showToast({
              title: '注册失败，请与管理员联系',
              icon: 'none'
            })
  
            console.error('[用户] [增加记录] 失败：', err)
          }
  
        })
      }
      
    } else {
      //用户按了拒绝按钮
      wx.showModal({
        title: '警告',
        content: '您点击了拒绝授权，将无法进入小程序，请授权之后再进入!!!',
        showCancel: false,
        confirmText: '返回授权',
        success: function (res) {
          // 用户没有授权成功，不需要改变 isHide 的值
          if (res.confirm) {
            console.log('用户点击了“返回授权”');
          }
        }
      });
    }

  },

  //设置信箱编码
  LetterBoxCode: function (e) {
    var that = this
    that.setData({
      LetterBoxCode: e.detail.value
    })
  },

  /**
   * 检查信箱合法性
   * @param {} e 
   */
  checkValidity: function (e) {
    var that = this
    if (that.data.LetterBoxCode == '' | that.data.LetterBoxCode == "公开") {
      wx.showModal({
        title: '提示！',
        content: '信箱编码非法！信箱编码仅由1-11位任意字符组成，不包括"公开"',
        showCancel: false,
      })
    } else {
      db.collection('User').where({
        LetterBoxCode: that.data.LetterBoxCode
      }).get({
        success: res => {
          if (res.data.length != 0) {
            wx.showModal({
              title: '提示！',
              content: '信箱编码已被占用！',
              showCancel: false,
            })
          } else {
            wx.showToast({
              title: '编码可用，请授权登录',
              icon: 'none'
            })
            that.setData({
              checked: true
            })
          }
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '查询记录失败'
          })
          console.error('[数据库] [查询记录] 失败：', err)
        }
      })
    }
  },




  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
 
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})