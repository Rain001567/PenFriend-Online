var util = require('../../../../utils/util.js')
const db = wx.cloud.database()
const _ = db.command
const app = getApp()
var temp = []

Page({

  /**
   * 页面的初始数据
   */
  data: {
    _openid: "", //当前用户的唯一标识
    key: [], //保存显示的信件
    letterNums: 0, //对应查询信箱记录数目
    ID: "", //信件ID
    DBN: "Focus", //查看信封详情时查询的数据库名称
    count: 0, //用来记录互相关注的人数
    choose: 0, //choose用来表明当前显示的是哪种类型的关注者
    FSSC: 0, //关注状态初始化计数
    userdata: "", //当前用户数据
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (choose) {
    var that = this;
    wx.cloud.callFunction({
      name: 'login',
      complete: res => {
        that.setData({
          _openid: res.result.openid,
          choose: choose.id,
          ShowImage: app.globalData.ShowImage
        })
        that.onShow(choose.id)
      }
    })

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function (choose) {

    var that = this
    that.setData({
      ShowImage: app.globalData.ShowImage
    })

    if (that.data._openid != "") {
      if (choose == "2") { //我的粉丝
        console.log('断点1')
        db.collection(that.data.DBN).where({
          BeFollower: that.data._openid
        }).orderBy('time', 'desc').get({
          success: res => {
            if (res.data.length == 0) {
              wx.showToast({
                title: '尚未有粉丝，返回笔友页面',
                icon: 'none',
                duration: 2000,
                success: function () {
                  setTimeout(function () {
                    wx.navigateBack({
                      url: '/pages/mine/penfriend/penfriend'
                    })
                  }, 2000);
                }
              })
            }


            temp = res.data
            for (var i = 0; i < temp.length; i++) {
              that.setFocusStatus(i, temp.length)
            }

          },
          fail: err => {
            wx.showToast({
              icon: 'none',
              title: '我的粉丝录查询失败'
            })
            console.error('[数据库] [查询记录] 失败：', err)
          }
        })
      } else {
        console.log('断点2')
        db.collection(that.data.DBN).where({
          Follower: that.data._openid
        }).orderBy('time', 'desc').get({
          success: res => {
            console.log('断点2-1')
            console.log(res)
            if (res.data.length == 0) {

              wx.showToast({
                title: '尚未关注任何人，返回笔友页面',
                icon: 'none',
                duration: 2000,
                success: function () {
                  setTimeout(function () {
                    wx.navigateBack({
                      url: '/pages/mine/penfriend/penfriend'
                    })
                  }, 2000);
                }
              })
            }
            console.log('断点2-2')

            var result = res.data
            for (var i = 0; i < result.length; i++) {
              result[i].focus = true
            }
            if (choose == "3") {

              for (var i = 0; i < result.length; i++) {
                that.isAlsoFollowMe(result[i], result.length)
              }

            } else {

              that.setData({
                key: result
              })
       
            }

          },
          fail: err => {
            wx.showToast({
              icon: 'none',
              title: '查询记录失败'
            })
            console.error('[数据库] [查询记录] 失败：', err)
          }
        })
      }
    }


  },

  /**
   * 
   * @param {每一位关注的人} data 
   * @param {我的关注人数} length 
   */
  isAlsoFollowMe(data, length) {
    var that = this
    console.log(data)
    //  console.log(that.data)
    db.collection(that.data.DBN).where({
      BeFollower: that.data._openid,
      Follower: data.BeFollower
    }).orderBy('time', 'desc').get({
      success: res => {
        console.log("断点6")
        that.setData({
          count: that.data.count + 1
        })
        if (res.data.length != 0) {
          temp.push(data)
        }
        console.log("断点7")
        if (length == that.data.count) {
          if (temp.length == 0) {
            wx.showToast({
              title: '尚未尚未关注任何人，返回笔友页面',
              icon: 'none',
              duration: 2000,
              success: function () {
                setTimeout(function () {
                  wx.navigateBack({
                    url: '/pages/mine/penfriend/penfriend'
                  })
                }, 2000);
              }
            })
          }




          that.setData({
            key: temp,
            count: 0
          })
          console.log(that.data)
          console.log('断点5')
          temp = []
        }

      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '我的粉丝录查询失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
      }
    })

  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },



  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var that = this
    wx.showLoading({
      title: '刷新中！',
      duration: 1000
    })
    //---------------------再取20条数据---------------------上边界//
    var x = that.data.letterNums + 20
    var old_data = that.data.key
    if (that.data.choose == "2") {
      db.collection(that.data.DBN).where({
        BeFollower: that.data._openid
      }).orderBy('time', 'desc').skip(x).get({
        success: res => {
          if (res.data.length == 0) {
            wx.showToast({
              title: '已经到底了',
              icon: 'none'
            })
          } else {
            that.setData({
              key: old_data.concat(res.data),
              letterNums: x
            })
          }

        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '查询记录失败'
          })
          console.error('[数据库] [查询记录] 失败：', err)
        }
      })
    } else {
      db.collection(that.data.DBN).where({
        Follower: that.data._openid
      }).orderBy('time', 'desc').skip(x).get({
        success: res => {
          if (res.data.length == 0) {
            wx.showToast({
              title: '已经到底了',
              icon: 'none'
            })
          } else {
            that.setData({
              key: old_data.concat(res.data),
              letterNums: x
            })
            if (that.data.choose == "3") {
              for (var i = 0; i < that.data.key.length; i++) {
                that.isAlsoFollowMe(that.data.key[i])
              }
            }

          }

        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '查询记录失败'
          })
          console.error('[数据库] [查询记录] 失败：', err)
        }
      })

    }
    //---------------------再取20条数据---------------------下边界//
  },




  /**
   * （被)关注者详情
   * @param {}} e 
   */
  onFollowerDetailTap: function (e) {
    var that = this

    if (that.data.choose != "3") {
      wx.showToast({
        title: '在互相关注界面才可查看用户主页',
        icon: 'none',
        duration: 2000,
        success: function () {
          setTimeout(function () {}, 2000);
        }
      })
    } else {
      var HomeId = e.currentTarget.dataset.homeid
      db.collection('User').where({
        _openid: that.data.key[HomeId].BeFollower
      }).get({
        success: res => {
          if (res.data[0].Visible == false) {
            wx.showToast({
              title: '该用户尚未公开其主页',
              icon: 'none',
              duration: 2000,
              success: function () {
                setTimeout(function () {

                }, 2000);
              }
            })
          } else {
            wx.navigateTo({
              url: '/pages/mine/infoDetail/infoDetail?id=' + that.data.key[HomeId].BeFollower,
            })
          }

        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '我的粉丝录查询失败'
          })
          console.error('[数据库] [查询记录] 失败：', err)
        }
      })



    }




  },

  /**
   * 点击按钮进行取消关注或者关注
   * @param {}} e 
   */
  focus: function (e) {
    var that = this
    var HomeId = e.currentTarget.dataset.homeid
    wx.getUserInfo({
      success: function (res) {
        that.setData({
          userdata: res.userInfo
        })
        console.log(that.data.key[HomeId])
        if (e.target.id == "1") {
          db.collection('Focus').add({
            data: {
              BeFollower: that.data.key[HomeId].Follower,
              BeFollowerName: that.data.key[HomeId].FollowerName,
              BeFollowerAvatarUrl: that.data.key[HomeId].FollowerAvatarUrl,
              Follower: that.data._openid, //无法添加——openid字段，未找到原因，猜测是保留字段无法设置
              FollowerAvatarUrl: that.data.userdata.avatarUrl,
              FollowerName: that.data.userdata.nickName,
              focus: true
            },
            success: res => {
              //   console.log(that.data.key[HomeId].focus)
              var item = 'key[' + HomeId + '].focus'
              that.setData({
                [item]: true
              }, function () { //setdata的回调函数
                wx.showToast({
                  title: '关注成功',
                })
                //      console.log(that.data.key[HomeId])
              })


              //----------------------------------给被关注者，发送关注通知消息----------------------------上//
              var time = util.formatTime(new Date())
              var content = "用户" + that.data.userdata.nickName + "在" + time + "时关注了你"
              db.collection('Message').add({
                data: {
                  time: time,
                  content: content,
                  type: 1, //类型1代表关注消息，类型2代表系统通知
                  receiverId: that.data.key[HomeId]._openid //信息接收者的id
                },
                success: res => {
                  console.log('[关注消息] [新增记录] 失败：', err)

                },
                fail: err => {

                  console.error('[关注消息] [新增记录] 失败：', err)
                }
              })
              //----------------------------------给被关注者，发送关注通知消息----------------------------下//

            },
            fail: err => {
              wx.showToast({
                icon: 'none',
                title: '关注失败'
              })
              console.error('[数据库] [新增记录] 失败：', err)
            }
          })
        } else if (e.target.id == "2") {
          wx.cloud.callFunction({
            name: "remove",
            data: {
              _id: that.data.key[HomeId]._id,
              databaseName: "Focus"
            },
            success: res => {
              if (that.data.choose == "2") {
                var item = 'key[' + HomeId + '].focus'
                that.setData({
                  [item]: false
                }, function () { //setdata的回调函数
                  wx.showToast({
                    title: '取消关注成功',
                  })
                })

              } else {
                var temp2 = that.data.key
                for (var i = 0; i < temp2.length; i++) {
                  if (temp2[i]._id == that.data.key[HomeId]._id) {
                    temp2.splice(i, 1);
                    that.setData({
                      key: temp2
                    }, function () {
                      wx.showToast({
                        title: '取消关注成功！！',
                      })
                      if(that.data.key.length == 0){
                        wx.showToast({
                          title: '目前已没有关注任何用户，返回关注页面',
                          icon: 'none',
                          duration: 2000,
                          success: function () {
                            setTimeout(function () {
                              wx.navigateBack({
                                url: '/pages/mine/penfriend/penfriend'
                              })
                            }, 2000);
                          }
                        })
                      }

                      
                      
                    })
                  }
                }
              }


              //----------------------------------给被关注者，发送取消关注通知消息----------------------------上//
              var time = util.formatTime(new Date())
              var content = "用户" + that.data.userdata.nickName + "在" + time + "时取消了对你的关注"
              db.collection('Message').add({
                data: {
                  time: time,
                  content: content,
                  type: 1, //类型1代表关注消息，类型2代表系统通知，3代表已读消息
                  receiverId: that.data.key[HomeId]._openid, //信息接收者的id
                },
                success: res => {
                  console.log('[关注消息] [新增记录] 失败：', err)

                },
                fail: err => {

                  console.error('[关注消息] [新增记录] 失败：', err)
                }
              })
              //----------------------------------给被关注者，发送取消关注通知消息----------------------------下//
            },
            fail: err => {
              wx.showToast({
                title: '取消关注失败' + err,
              })

            }
          })

        } else {

        }


      }
    })


  },

  setFocusStatus: function (i, userNum) {
    var that = this
    db.collection('Focus').where({
      Follower: that.data._openid, //关注者
      BeFollower: temp[i]._openid //被关注者
    }).get({
      success: res => {
        console.log(res.data.length)
        temp[i].focus = (res.data.length != 0)
        that.setData({
          FSSC: that.data.FSSC + 1
        })
        if (that.data.FSSC == userNum) {
          that.setData({
            key: temp,
            FSSC:0
          })
          temp = []
        }
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '关注状态初始化失败'
        })
      }
    })


    that.setData({
      key: res.data
    })
  }

})