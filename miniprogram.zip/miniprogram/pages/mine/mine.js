// pages/mine/mine.js
const db = wx.cloud.database()
const _ = db.command
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userSrc : "https://s1.ax1x.com/2020/05/22/YXpV1g.png",
      userName : "用户名",
    LetterBoxCode:"", //用户信箱编码
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
   var that = this
   wx.cloud.callFunction({
    name: 'login',
    complete: res => {
      that.setData({
        _openid: res.result.openid,
        ShowImage:app.globalData.ShowImage
      })
    }
  })
   wx.getUserInfo({
     complete: (res) => {
      that.setData({
        userSrc :res.userInfo.avatarUrl,
        userName : res.userInfo.nickName,
      });

      db.collection('User').where({
        avatarUrl: res.userInfo.avatarUrl
      }).get({
        success: res => {
          that.setData({
            LetterBoxCode:res.data[0].LetterBoxCode
          })

        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '用户信息查询失败'
          })
          console.error('[数据库] [查询记录] 失败：', err)
        }
      })
     },
   })
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this
    that.setData({
      ShowImage:app.globalData.ShowImage
    })
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  onMyPageTap:function(){
    var that = this
    wx.navigateTo({
      url: 'infoDetail/infoDetail?id='+that.data._openid,
    })
  },
  onPenFriendPageTap:function(){
    wx.navigateTo({
      url: 'penfriend/penfriend',
    })
  },
  onMessagePageTap:function(){
    wx.navigateTo({
      url: 'message/message',
    })
  },
  onLetterBoxPageTap:function(){
    wx.navigateTo({
      url: 'LetterBox/LetterBox'
    })
  },
  onCollectPageTap:function(){
    // slideSwitch.call(this, false);
    wx.navigateTo({
      url: 'collected/collected'
    })
  },
  onSettingPageTap:function(){
    wx.navigateTo({
      url: 'setting/setting'
    })
  },


})