// pages/home/home.js
//获取homedata中数据，从服务器中获取的数据


const db = wx.cloud.database()
const _ = db.command
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    _openid: "", //当前用户的唯一标识
    key: [], //保存显示的信件
    letterNums: 0, //对应查询信箱记录数目
    ID: "", //信件ID
    DBN: "", //查看信封详情时查询的数据库名称
    ShowPart: 0,
    DBNlist: ['Send', 'Receive', 'Collected']
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (choose) {
    var that = this;
    wx.cloud.callFunction({
      name: 'login',
      complete: res => {
        that.setData({
          _openid: res.result.openid,
          ShowPart: choose.id,
          DBN: that.data.DBNlist[choose.id - 1],
          ShowImage: app.globalData.ShowImage
        })
        that.onShow(choose.id)
        console.log(that.data)
      }
    })

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function (choose) {
    var that = this
    that.setData({
      ShowImage: app.globalData.ShowImage
    })
    if (choose == 1) {
      db.collection(that.data.DBN).where({
        _openid: that.data._openid
      }).orderBy('time', 'desc').get({
        success: res => {
          that.dealResult(choose, res.data)
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '历史发送记录查询失败'
          })
          console.error('[数据库] [查询记录] 失败：', err)
        }
      })
    } else if (choose == 2) {
      db.collection(that.data.DBN).where({
        receiverId: that.data._openid
      }).orderBy('time', 'desc').get({
        success: res => {
          that.dealResult(choose, res.data)
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '查询记录失败'
          })
          console.error('[数据库] [查询记录] 失败：', err)
        }
      })
    } else if (choose == 3) {
      db.collection(that.data.DBN).where({
        collecterId: that.data.openid
      }).orderBy('time', 'desc').get({
        success: res => {
          that.dealResult(choose, res.data)
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '查询记录失败'
          })
          console.error('[数据库] [查询记录] 失败：', err)
        }
      })

    }

  },

  /**
   * 处理搜索的结果
   */
  dealResult: function (choose, resdata) {
    var that = this
    var name = ['历史发送', '收信', '收藏']
    if (resdata.length == 0) {
      wx.showToast({
        title: '尚未有' + name[choose - 1] + '信件，返回信箱页面',
        icon: 'none',
        duration: 2000,
        success: function () {
          setTimeout(function () {
            wx.navigateBack({
              url: '/pages/home/home',
            })
          }, 2000);
        }
      })
    }
    that.setData({
      key: resdata
    })
    if (choose != 3) {
      for (var i = 0; i < that.data.key.length; i++) {
        that.setCollectStatus(i)
      }
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },
  /**
   * 设置信封的收藏状态
   * @param {信封的搜索记录索引} choose 
   */
  setCollectStatus: function (choose) {
    var that = this
    db.collection('Collected').where({
      collecterId: that.data._openid,
      LetterId: that.data.key[choose]._id
    }).get({
      success: res => {

        var item = 'key[' + choose + '].like'
        var bool = (res.data.length != 0)
        //  console.log("boolvalue  "+bool)                      
        that.setData({
          [item]: bool
        }, function () { //setdata的回调函数

        })
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '收藏状态更新失败'
        })
        console.error('[数据库] [新增记录] 失败：', err)
        return choose
      }
    })
  },


  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var that = this
    wx.showLoading({
      title: '刷新中！',
      duration: 1000
    })
    //---------------------再取20条数据---------------------上边界//
    var x = that.data.letterNums + 20
    var old_data = that.data.key
    if (that.data.ShowPart == 1) {
      that.setData({
        DBN: 'Send'
      })
      db.collection('Send').where({
        _openid: that.data._openid
      }).orderBy('time', 'desc').skip(x).get({
        success: res => {
          if (res.data.length == 0) {
            wx.showToast({
              title: '已经到底了',
              icon: 'none'
            })
          } else {
            that.setData({
              key: old_data.concat(res.data),
              letterNums: x
            })
            console.log(res.data)
          }

        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '查询记录失败'
          })
          console.error('[数据库] [查询记录] 失败：', err)
        }
      })

    } else if (that.data.ShowPart == 2) {
      that.setData({
        DBN: 'Revceive'
      })
      db.collection('Receive').where({
        receiverId: that.data._openid
      }).orderBy('time', 'desc').skip(x).get({
        success: res => {
          if (res.data.length == 0) {
            wx.showToast({
              title: '已经到底了',
              icon: 'none'
            })
          } else {
            that.setData({
              key: old_data.concat(res.data),
              letterNums: x
            })
            console.log(res.data)
          }
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '查询记录失败'
          })
          console.error('[数据库] [查询记录] 失败：', err)
        }
      })


    } else if (that.data.ShowPart == 3) {
      that.setData({
        DBN: 'Collected'
      })
      db.collection('Collected').where({
        collecterId: that.data.openid
      }).orderBy('time', 'desc').skip(x).get({
        success: res => {
          if (res.data.length == 0) {
            wx.showToast({
              title: '已经到底了',
              icon: 'none'
            })
          } else {
            that.setData({
              key: old_data.concat(res.data),
              letterNums: x
            })
            console.log(res.data)
          }

        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '查询记录失败'
          })
          console.error('[数据库] [查询记录] 失败：', err)
        }
      })

    } else {

    }
    //---------------------再取20条数据---------------------下边界//
  },


  //-------------------------------收藏/取消收藏-------------------------------上边界//
  onCollected: function (e) {
    console.log(e)
    var that = this
    var HomeId = e.currentTarget.dataset.homeid
    var homeTui = that.data.key //数据数组
    var like = homeTui[HomeId].like
    var collect = homeTui[HomeId].collect
    like = !like
    homeTui[HomeId].like = like

    var updateid //用于更新收藏状态
    updateid = homeTui[HomeId]._id
    if (like == true) {
      collect += 1
      db.collection('Collected').add({
        data: {
          LetterId: homeTui[HomeId]._id,
          _openid: homeTui[HomeId].openid,
          avatar: homeTui[HomeId].avatar,
          collect: homeTui[HomeId].collect + 1,
          content: homeTui[HomeId].content,
          contentdetail: homeTui[HomeId].contentdetail,
          like: true,
          nickName: homeTui[HomeId].nickName,
          reading: homeTui[HomeId].reading,
          receiverId: homeTui[HomeId].receiverId,
          time: homeTui[HomeId].time,
          collecterId: that.data._openid,
        },
        success: res => {

          wx.showToast({
            title: '收藏成功',
          })

        },

      })
    } else {
      collect -= 1
      console.log("断点2")

      var delID;
      if (that.data.ShowPart != 3) {
        delID = homeTui[HomeId]._id
      } else {
        delID = homeTui[HomeId].LetterId
      }

      db.collection('Collected').where({
        collecterId: that.data._openid,
        LetterId: delID
      }).get({
        success: res => {
          //       console.log("断点3")
          //     console.log(res)
          var ID = res.data[0]._id
          //  console.log("ID="+ID)
          wx.cloud.callFunction({
            name: "remove",

            data: {
              _id: ID,
              databaseName: "Collected"
            },
            success: res => {

              wx.showToast({
                title: '取消收藏成功！！',
              })
              if (that.data.ShowPart == 3) {
                that.onShow(3)
              }
            },
            fail: err => {
              wx.showToast({
                title: '取消收藏失败' + err,
              })

            }
          })
        }
      })


    }
    if (that.data.ShowPart != 3) {
      homeTui[HomeId].collect = collect
      that.setData({
        key: homeTui
      })
    }
    db.collection('Letter').doc(updateid).update({
      data: {
        collect: collect
      },
      success: res => {
        console.log("更新成功")
      }
    })

  },
  //-------------------------------收藏/取消收藏-------------------------------上边界//


  /**
   * 信件详情
   * @param {}} e 
   */
  onHomeDetailTap: function (e) {

    var that = this
    var HomeId = e.currentTarget.dataset.homeid
    console.log(that.data.DBN)
    console.log(that.data.key[HomeId]._id)
    db.collection(that.data.DBN).where({
      _id: that.data.key[HomeId]._id,
    }).get({

      success: res => {
        //   console.log(that.data.DBN)
        if (res.data.length == 0) {
          return;
        }
        console.log(res)
        wx.cloud.callFunction({
          name: "UpdateField",
          data: {
            _id: that.data.key[HomeId]._id,
            DBN: that.data.DBN,
            fieldvalue: res.data[0].reading + 1
          },
          success: res => {
            console.log('阅读数更改成功')
            wx.navigateTo({
              url: '/pages/home/home-detail/home-detail?id=' + that.data.key[HomeId]._id + '&DBN=' + that.data.DBN,
            })
          },
          fail: err => {
            console.log(that.data.key[HomeId]._id)
            console.log(err)
            console.log('阅读数更改失败')
            wx.navigateTo({
              url: '/pages/home/home-detail/home-detail?id=' + that.data.key[HomeId]._id + '&DBN=' + that.data.DBN,
            })
          }
        })
        console.log('[阅读数] [查询记录] 成功: ', res)
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '查询记录失败'
        })
        console.error('[阅读数] [查询记录] 失败：', err)
      }
    })


  },

  Del: function (e) {
    var that = this
    console.log(e)
    wx.showModal({
      title: '警告',
      content: '信件删除后无法恢复，是否继续删除',
      confirmText: '确认删除',
      success: function (res) {
        // 用户没有授权成功，不需要改变 isHide 的值
        if (res.confirm) {
          
          var HomeId = e.currentTarget.dataset.homeid
          
       //   console.log(HomeId)
        //  console.log('断点 del')
      //    console.log(that.data.key[HomeId])
          var ID = that.data.key[HomeId]._id
          var temp1 = []
          temp1 = that.data.key
          for (var i = 0; i < temp1.length; i++) {
            if (temp1[i]._id == ID) {
              temp1.splice(i, 1);
              that.setData({
                key: temp1
              }, function () {

                wx.showToast({
                  icon: 'success',
                  title: '删除成功'
                })
               
              })
              break
            }
          }
          wx.cloud.callFunction({
            name: "remove",
            data: {
              _id: ID,
              databaseName: that.data.DBN
            },
            success: res => {
              
            },
            fail: err => {
              wx.showToast({
                title: '后台数据库删除失败' + err,
              })
            }
          })
        }
      }
    });

  }

})