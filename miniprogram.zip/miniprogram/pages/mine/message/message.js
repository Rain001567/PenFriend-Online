// pages/mine/message/message.js
const db = wx.cloud.database()
const _ = db.command
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ShowMessage: false, // false代表显示信息类别，true代表显示搜索结果。
    searchKey: "", //搜索关键字
    _openid: "",
    ShowSearchResutl:false,
    Message: [], //保存显示的信件
    
    letterNums: 0, //信息加载跳过数（从数据库读取的开始位置）
    letterNums2: 0, //
    ID: "", //信件ID
    DBN: "Message", //页面数据来源数据库名称
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    wx.cloud.callFunction({
      name: 'login',
      complete: res => {
        that.setData({
          _openid: res.result.openid
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  /**
   * 点击查看不同类别的信息
   * @param {*} e 对应的点击时间 id代表类型 
   */
  tap: function (e) {
    if (e.currentTarget.id == 'r1') {
      wx.navigateTo({
        url: '/pages/mine/message/MessageDetail/MessageDetail?id=' + 1,
      })
    } else if (e.currentTarget.id == 'r2') {
      wx.navigateTo({
        url: '/pages/mine/message/MessageDetail/MessageDetail?id=' + 2,
      })

    }  else if (e.currentTarget.id == 'r3') {
      wx.navigateTo({
        url: '/pages/mine/message/MessageDetail/MessageDetail?id=' + 3,
      })

    }else{
      
    }
  },


  
})