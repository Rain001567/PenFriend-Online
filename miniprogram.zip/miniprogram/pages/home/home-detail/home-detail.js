// pages/home/home-detail/home-detail.js
//获取homedata中数据，从服务器中获取的数据
var util = require('../../../utils/util.js')
var postHome = require('../../../data/home-data.js');
const db = wx.cloud.database()
const _ = db.command

const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    _id: "", //详情页信封id
    DBN: "", //详情页信封所在的数据库名称
    currentUserName: "", //当前用户昵称
    avatarUrl: "", //当前用户头像链接
    comment: "", //当前用户对于信件的评论
    _openid: 0,
    homeData: {
      LetterBoxCode: "",
      _openid: "",
      collect: 0,
      comments: ["   "],
      content: "",
      contentdetail: "",
      like: false,
      nickName: "",
      reading: 0,
      receiverId: "",
      time: null,
      id: "",
      avatar: "",
     
    },
    focus: false, //false表明当前用户尚未关注当前作者
    CommentsResult: [], //评论数组
    CommentValue: "", //评论内容

  }, //信件对象


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    wx.cloud.callFunction({
      name: 'login',
      complete: res => {
        that.setData({
          _openid: res.result.openid,
          _id: options.id,
          DBN: options.DBN,
          ShowImage:app.globalData.ShowImage
        }, function () {

          db.collection(that.data.DBN).where({
            _id: that.data._id
          }).get({
            success: res => {
              if (res.data.length != 0) {
                that.setData({
                  homeData: res.data[0]
                })
                db.collection('Focus').where({
                  Follower: that.data._openid, //关注者
                  BeFollower: that.data.homeData._openid //被关注者
                }).get({
                  success: res => {
                    console.log(res.data.length)
                    that.setData({
                      focus: (res.data.length != 0)
                    })
                  },
                  fail: err => {

                    wx.showToast({
                      icon: 'none',
                      title: '关注状态初始化失败'
                    })

                  }
                })
              } else {
                wx.showToast({
                  title: '当前信封可能已经被删除，返回刚才页',
                  icon: 'none'
                })
                wx.navigateBack({
                  delta: 1
                })
              }
            },
            fail: err => {
              wx.showToast({
                icon: 'none',
                title: '[页面详情]查询记录失败'
              })

            }
          })

        })




      }
    })

  },

  /**
   * 
   * 发布评论函数
   */
  sendcomment: function () {
    var that = this
    wx.getUserInfo({
      success: function (res) {
        that.setData({
          avatarUrl: res.userInfo.avatarUrl,
        })
        wx.cloud.callFunction({
          name: "UpdateComments",
          data: {
            _id: that.data._id,
            DBN: that.data.DBN,
            object: {
              nickName: that.data.homeData.nickName,
              comment: that.data.comment,
              time: util.formatTime(new Date()),
              avatarUrl: that.data.avatarUrl,
            }
          },
          success: res => {
            wx.showToast({
              title: '发布评论成功',
            })
            that.onShow()

          },
          fail: err => {
            wx.showToast({
              title: '发布评论失败',
            })
            console.log(err)
          }
        })
      }
    })
    






  },

  /**
   * 
   */
  commentInput: function (e) {
    var that = this
    that.setData({
      comment: e.detail.value
    })
  },
  /**
   * 点击按钮进行取消关注或者关注
   * @param {}} e 
   */
  focus: function (e) {
    var that = this
    wx.getUserInfo({
      success: function (res) {
        that.setData({
          currentUserName: res.userInfo.nickName,
        })
        if (e.target.id == "1") {


          db.collection('Focus').add({
            data: {
              BeFollower: that.data.homeData._openid,
              BeFollowerName:that.data.homeData.nickName,
              BeFollowerAvatarUrl:that.data.homeData.avatar,
              Follower: that.data._openid, //无法添加——openid字段，未找到原因，猜测是保留字段无法设置
              FollowerAvatarUrl:that.data.avatarUrl,
              FollowerName:that.data.currentUserName,
              focus:false
            },
            success: res => {
              wx.showToast({
                title: '关注成功',
              })
              that.setData({
                focus: true
              })
              //----------------------------------给被关注者，发送关注通知消息----------------------------上//
              var time = util.formatTime(new Date())
              var content = "用户" + that.data.currentUserName + "在" + time + "时关注了你"
              db.collection('Message').add({
                data: {
                  time: time,
                  content: content,
                  type: 1, //类型1代表关注消息，类型2代表系统通知
                  receiverId: that.data.homeData._openid //信息接收者的id
                },
                success: res => {
                  console.log('[关注消息] [新增记录] 失败：', err)
    
                },
                fail: err => {
    
                  console.error('[关注消息] [新增记录] 失败：', err)
                }
              })
              //----------------------------------给被关注者，发送关注通知消息----------------------------下//
    
            },
            fail: err => {
              wx.showToast({
                icon: 'none',
                title: '关注失败'
              })
              console.error('[数据库] [新增记录] 失败：', err)
            }
          })
        } else if (e.target.id == "2") {
          db.collection('Focus').where({
            Follower: that.data._openid,
            BeFollower: that.data.homeData._openid
          }).get({
            success: res => {
              if (res.data.length != 0) {
                wx.cloud.callFunction({
                  name: "remove",
                  data: {
                    _id: res.data[0]._id,
                    databaseName: "Focus"
                  },
                  success: res => {
                    wx.showToast({
                      title: '取消关注成功！！',
                    })
                    that.setData({
                      focus: false
                    })
                    //----------------------------------给被关注者，发送取消关注通知消息----------------------------上//
                    var time = util.formatTime(new Date())
                    var content = "用户" + that.data.currentUserName + "在" + time + "时取消了对你的关注"
                    db.collection('Message').add({
                      data: {
                        time: time,
                        content: content,
                        type: 1, //类型1代表关注消息，类型2代表系统通知，3代表已读消息
                        receiverId: that.data.homeData._openid, //信息接收者的id
                      },
                      success: res => {
                        console.log('[关注消息] [新增记录] 失败：', err)
    
                      },
                      fail: err => {
    
                        console.error('[关注消息] [新增记录] 失败：', err)
                      }
                    })
                    //----------------------------------给被关注者，发送取消关注通知消息----------------------------下//
                  },
                  fail: err => {
                    wx.showToast({
                      title: '取消关注失败' + err,
                    })
    
                  }
                })
              } else {
                wx.showToast({
                  icon: 'none',
                  title: '取消关注失败，未查到关注信息'
                })
              }
    
    
            },
            fail: err => {
              wx.showToast({
                icon: 'none',
                title: '取消关注失败，未查到关注信息'
              })
            }
    
          })
    
        } else {
    
        }
      
      
      }
    })


  },












  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this
    wx.getUserInfo({
      success: function (res) {
        that.setData({
          avatarUrl: res.userInfo.avatarUrl,
          CommentValue: "",
      ShowImage:app.globalData.ShowImage
        })
        
      }
    })
    
    if (that.data._id != "") {
      db.collection(that.data.DBN).where({
        _id: that.data._id
      }).get({
        success: res => {
          if (res.data.length != 0) {
            that.setData({
              homeData: res.data[0]
            })
          } else {
            wx.showToast({
              title: '当前信封可能已经被删除，返回刚才页',
              icon: 'none'
            })
            wx.navigateBack({
              delta: 1
            })
          }
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '[页面详情]查询记录失败'
          })
        }
      })
    }

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

})