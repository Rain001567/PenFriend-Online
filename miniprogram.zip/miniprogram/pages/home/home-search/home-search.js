// pages/home/home-search/home-search.js

const app = getApp()
const db = wx.cloud.database()
const _ = db.command
Page({

  /**result
   * 页面的初始数据
   */
  data: {
    userLength: [], //用户名宽度
    keyLength: [], //关键字宽度
    searchKey: "",
    ShowResult: false, //ShowReult 为true表示显示搜索结果
    user: [], //保存了用户名,
    SearchResult: [], //搜索结果
    letterNums: 0, //搜索结果的加载跳过数
    LetterNum: 0, //系统目前的公开信件数
    myCollectNum: 0,
    _openid: 0,
    loopvalue: 0,
    DBN: "Letter", //查看信封详情时查询的数据库名称
    _id: "",

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options, ResultLength) {
    var that = this
    //   console.log("home-search onload")
    wx.cloud.callFunction({
      name: 'login',
      complete: res => {
        that.setData({
          _openid: res.result.openid,
          ShowImage:app.globalData.ShowImage
        })
      }
    })
  },

  /**
   * 设置信封的收藏状态
   * @param {信封的搜索记录索引} choose 
   */
  setCollectStatus: function (choose) {
    var that = this
    db.collection('Collected').where({
      collecterId: that.data._openid,
      LetterId: that.data.SearchResult[choose]._id
    }).get({
      success: res => {

        var item = 'SearchResult[' + choose + '].like'
        var bool = (res.data.length != 0)
        //  console.log("boolvalue  "+bool)                      
        that.setData({
          [item]: bool
        }, function () { //setdata的回调函数

        })
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '收藏状态更新失败'
        })
        console.error('[数据库] [新增记录] 失败：', err)
        return choose
      }
    })
  },



  //收藏和取消收藏
  onCollected: function (e) {

    var that = this

    const db = wx.cloud.database()

    var HomeId = e.currentTarget.dataset.homeid
    var homeTui = that.data.SearchResult //数据数组
    var like = homeTui[HomeId].like
    var collect = homeTui[HomeId].collect
    like = !like
    homeTui[HomeId].like = like

    if (like == true) {
      collect += 1
      db.collection('Collected').add({
        data: {
          LetterId: homeTui[HomeId]._id,
          _openid: homeTui[HomeId].openid,
          avatar: homeTui[HomeId].avatar,
          collect: homeTui[HomeId].collect + 1,
          content: homeTui[HomeId].content,
          contentdetail: homeTui[HomeId].contentdetail,
          like: true,
          nickName: homeTui[HomeId].nickName,
          reading: homeTui[HomeId].reading,
          receiverId: homeTui[HomeId].receiverId,
          time: homeTui[HomeId].time,
          collecterId: that.data._openid,
        },
        success: res => {

          wx.showToast({
            title: '收藏成功',
          })

        },

      })
    } else {
      collect -= 1
      db.collection('Collected').where({
        collecterId: that.data._openid,
        LetterId: homeTui[HomeId]._id
      }).get({
        success: res => {

          var ID = res.data[0]._id

          wx.cloud.callFunction({
            name: "remove",

            data: {
              _id: ID,
              databaseName: "Collected"
            },
            success: res => {

              wx.showToast({
                title: '取消收藏成功！！',
              })
            },
            fail: err => {
              wx.showToast({
                title: '取消收藏失败' + err,
              })

            }
          })




        }
      })


    }

    homeTui[HomeId].collect = collect
    that.setData({
      SearchResult: homeTui
    })


    db.collection('Letter').doc(homeTui[HomeId]._id).update({
      data: {
        collect: homeTui[HomeId].collect
      },
      success: res => {
        console.log("更新成功")
      }
    })
  },



  //保存搜索输入
  searchInput: function (e) {
    var that = this
    that.setData({
      searchKey: e.detail.value
    })

  },

  /**
   * 点击搜索按钮 上边界
   * @param {点击搜索按钮事件} e 
   */
  onSearchClickTap: function (e) {

    var that = this
    if (that.data.searchKey == "") {

      wx.showToast({
        title: '请输入搜索词!',
        icon: 'none',
        duration: 1000
      })

    } else {

      that.onRefresh()
    }
  },

  /**
   * 点击关键词 -上边界
   * @param {*} e 
   */
  onClickTap: function (e) {
    var that = this
    that.setData({
      searchKey: e.target.id
    })
    that.onRefresh()
  },
  /**
   * 点击关键词 -下边界
   * @param {*} e 
   */
  /**
   * 读取搜索结果
   */
  onRefresh: function () {
    var that = this
    wx.showToast({
      title: '加载中',
      icon: 'loading'
    })
    db.collection('Letter').where(_.or([{
        nickName: db.RegExp({
          regexp: '.*' + that.data.searchKey,
          options: 'i',
        })
      },
      {
        content: db.RegExp({
          regexp: '.*' + that.data.searchKey,
          options: 'i',
        })
      }
    ])).orderBy('time', 'desc').get({
      success: res => {
          that.setData({
            SearchResult: res.data,
            ShowResult:true
          }, () => {
            for (var i = 0; i < that.data.SearchResult.length; i++) {
              that.setCollectStatus(i)
            }
            wx.showToast({
              title: '搜索完成',
              icon: "success"
            })           
          })
      },
      fail: err => {
        console.log("初次获取搜索结果失败")
        console.log(err)
      }
    })
  },

  /**
   * 
   * @param {信件详情点击事件} e 
   */
  onHomeDetailTap: function (e) {
    var that = this
    var HomeId = e.currentTarget.dataset.homeid
    db.collection('Letter').where({
      _id: that.data.SearchResult[HomeId]._id,
    }).get({
      success: res => {

        wx.cloud.callFunction({
          name: "UpdateField",
          data: {
            _id: that.data.SearchResult[HomeId]._id,
            DBN: "Letter",
            fieldvalue: res.data[0].reading + 1
          },
          success: res => {
            console.log('阅读数更改成功')
            wx.navigateTo({
              url: '/pages/home/home-detail/home-detail?id=' + that.data.SearchResult[HomeId]._id,
            })
          },
          fail: err => {
            console.log(that.data.SearchResult[HomeId]._id)
            console.log(err)
            console.log('阅读数更改失败')
            wx.navigateTo({
              url: '/pages/home/home-detail/home-detail?id=' + that.data.SearchResult[HomeId]._id,

            })
          }
        })
        console.log('[阅读数] [查询记录] 成功: ', res)
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '查询记录失败'
        })
        console.error('[阅读数] [查询记录] 失败：', err)
      }
    })


  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this
    that.setData({
      ShowResult: false,
      ShowImage:app.globalData.ShowImage
    })
    var user = [] //用来保存用户名
    var key = [] //用来保存关键字
    var length = that.data.userLength
    var length2 = that.data.keyLength
    db.collection('User').aggregate().sample({
      size: 4
    }).end().then(
      res => {
        for (var i = 0; i < res.list.length; i++) {
          user.push(res.list[i].nickName)
          length.push(res.list[i].nickName.length * 43)
        }
        that.setData({
          user: user,
          userLength: length
        })
      })

    db.collection('Letter').aggregate().sample({
      size: 4
    }).end().then(
      res => {
        for (var i = 0; i < res.list.length; i++) {
          key.push(res.list[i].content)
          length2.push(res.list[i].content.length * 43)
        }
        that.setData({
          key: key,
          keyLength: length2
        })
      })

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {


  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  /**
   * 返回关键字界面按钮
   */
  btn: function () {
    var that = this;
    that.setData({
      ShowResult: false
    })
  },


})