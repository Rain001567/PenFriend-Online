// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

// 云函数入口函数
const db = cloud.database()
exports.main = async (event, context) => {
  
  return await db.collection(event.dataBaseName).where({
    collecterId: event._id // 填入当前用户 openid
  }).count()
}