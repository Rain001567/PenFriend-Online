//app.js

App({
  globalData: {
    userInfo: null,
    _openid: 0,
    myCollectNum: 0, //当前用户的收藏夹数目
    LetterNum: 0, //当前系统的信件数目
    ShowImage:true      //用来控制是否开启无图模式
  },

  onLaunch: function () {
    var that = this

    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力')
    } else {
      wx.cloud.init({
        // env 参数说明：
        //   env 参数决定接下来小程序发起的云开发调用（wx.cloud.xxx）会默认请求到哪个云环境的资源
        //   此处请填入环境 ID, 环境 ID 可打开云控制台查看
        //   如不填则使用默认环境（第一个创建的环境）
        env: 'movie-33kyc',
        traceUser: true,
      })
    }


  },


  //获取openid顺序：globalData--云函数login；如果担心openid的安全，就用这个函数
  

})