// pages/home/home.js
//获取homedata中数据，从服务器中获取的数据
var postHome = require('../../data/home-data.js');
const app = getApp()
const db = wx.cloud.database()
const _ = db.command

Page({

  /**
   * 页面的初始数据
   */
  data: {

    Total: true, //total为true代表显示全部
    searchKey: 0, //搜索关键字
    _openid: 0,
    key: [], //保存显示的信件
    i: 0,
    letterNums: 0,
    letterNums2: 0, //推荐页面的加载跳过数
    ID: "", //信件ID
    DBN: "Letter", //查看信封详情时查询的数据库名称
    loopValue: 0 //收藏状态设置循环数
  },




  /**
   * 生命周期函数--监听页面加载
   */

  onLoad: function (choose) {
    var that = this

    wx.getSetting({
      success(res) {
        if (!res.authSetting['scope.userInfo']) {
          wx.redirectTo({
            url: '/pages/authorization/authorization',
          })
        }else{
          wx.cloud.callFunction({
            name: 'login',
            complete: res => {
              that.setData({
                _openid: res.result.openid,
                ShowImage:app.globalData.ShowImage
              })
              
            }
          })
        }
      }
    })
    
    //设置home内容块的下部分
  },


  onSearchTap: function (e) {
    this.setData({
      searchKey: e.detail.value
    })
    wx.navigateTo({
      url: 'home-search/home-search',
    })
  },

  onSearchClickTap: function () {
    if (!this.data.searchKey) {
      wx.showToast({
        title: '请输入搜索词!',
        icon: 'none',
        duration: 1000
      })
      return
    }

  },







  /**
   * 切换推荐展示
   * @param {*} e 点击
   */
  onChangeTap: function (e) {
    var that = this

    if (e.target.id == "r1" & that.data.Total == false) { //正处于推荐，当前点击为全部
      that.onShow()
    } else if (e.target.id == "r2" & that.data.Total == true) { //正处于全部，当前点击为推荐
      that.onShow(true)
    } else {
      //正处于正确的位置，点击无意义
    }
  },













  onHomeDetailTap: function (e) {
    var that = this
    var HomeId = e.currentTarget.dataset.homeid
    db.collection('Letter').where({
      _id: that.data.key[HomeId]._id,
    }).get({
      success: res => {

        wx.cloud.callFunction({
          name: "UpdateField",
          data: {
            _id: that.data.key[HomeId]._id,
            DBN: "Letter",
            fieldvalue: res.data[0].reading + 1
          },
          success: res => {
            console.log('阅读数更改成功')
            wx.navigateTo({
              url: 'home-detail/home-detail?id=' + that.data.key[HomeId]._id + '&DBN=' + that.data.DBN,

            })

          },
          fail: err => {
            console.log(that.data.key[HomeId]._id)
            console.log(err)
            console.log('阅读数更改失败')
            wx.navigateTo({
              url: 'home-detail/home-detail?id=' + that.data.key[HomeId]._id,
            })
          }
        })
        console.log('[阅读数] [查询记录] 成功: ', res)
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '查询记录失败'
        })
        console.error('[阅读数] [查询记录] 失败：', err)
      }
    })


  },


  //收藏和取消收藏
  onCollected: function (e) {
    var that = this
    var HomeId = e.currentTarget.dataset.homeid //索引
    var homeTui = that.data.key //数据数组
    var like = homeTui[HomeId].like //收藏标志
    var collect = homeTui[HomeId].collect //收藏数
    like = !like
    homeTui[HomeId].like = like

    if (like == true) { //表明用户点击了收藏
      collect += 1
      db.collection('Collected').add({
        data: {
          LetterId: homeTui[HomeId]._id,
          _openid: homeTui[HomeId].openid,
          avatar: homeTui[HomeId].avatar,
          collect: homeTui[HomeId].collect + 1,
          content: homeTui[HomeId].content,
          contentdetail: homeTui[HomeId].contentdetail,
          like: true,
          nickName: homeTui[HomeId].nickName,
          reading: homeTui[HomeId].reading,
          receiverId: homeTui[HomeId].receiverId,
          time: homeTui[HomeId].time,
          collecterId: that.data._openid,
        },
        success: res => {
          wx.showToast({
            title: '收藏成功',
          })

        },
        fail: err => {
          wx.showToast({
            title: '收藏失败' + err,
          })
        }
      })
    } else {
      collect -= 1
      db.collection('Collected').where({
        collecterId: that.data._openid,
        LetterId: homeTui[HomeId]._id
      }).get({
        success: res => {
          var ID = res.data[0]._id
          wx.cloud.callFunction({
            name: "remove",
            data: {
              _id: ID,
              databaseName: "Collected"
            },
            success: res => {
              wx.showToast({
                title: '取消收藏成功！！',
              })
            },
            fail: err => {
              wx.showToast({
                title: '取消收藏失败' + err,
              })
            }
          })
        }
      })
    }

    homeTui[HomeId].collect = collect
    that.setData({
      key: homeTui
    })
    db.collection('Letter').doc(homeTui[HomeId]._id).update({
      data: {
        collect: homeTui[HomeId].collect
      },
      success: res => {
        console.log("home-信件收藏数更新成功")
      },
      fail: err => {
        console.log("home-信件收藏数更新失败")
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 
   * @param {recommend为true代表刚刚点击了推荐按钮} recommend 
   */
  onShow: function (recommend) {
    var that = this
    that.setData({
      letterNums: 0,
      letterNums2: 0,
      ShowImage:app.globalData.ShowImage
    })
    if (recommend == true) {
      that.setData({
        Total: false
      })

      db.collection('Letter').where({
        reading: _.gte(20) //此处根据阅读量过滤多余信件
      }).orderBy('reading', 'desc').get({
        success: res => {
          that.setData({
            key: res.data
          }, () => {
            wx.showToast({
              title: '加载完成,上划继续加载',
              icon: 'none'
            })
            if (that.data.key.length != 0) {
              for (var i = 0; i < that.data.key.length; i++) {
                that.setCollectStatus(i)
              }
            } else {
              wx.showToast({
                title: '目前尚暂无推荐公开信件，推荐标准：阅读量30+，返回全部查看',
                icon: 'none',
                success: function () {
                  setTimeout(function () { 
                    that.onShow()                
                  }, 2000);
                }
              })
            }
          })
        }
      })
    } else {
      that.setData({
        Total: true
      })
      db.collection(that.data.DBN).orderBy('time', 'desc').get({
        success: res => {
          that.setData({
            key: res.data
          }, () => {
            wx.showToast({
              title: '加载完成,上划继续加载',
              icon: 'none'
            })
            if (that.data.key.length != 0) {
              for (var i = 0; i < that.data.key.length; i++) {
                that.setCollectStatus(i)
              }
            } else {
              wx.showToast({
                title: '目前尚未有任何公开信件',
                icon: 'none',
                success: function () {
                  setTimeout(function () {             
                  }, 2000);
                }
              })
            }
          })
        }
      })
    }

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var that = this
    wx.showLoading({
      title: '刷新中！',
      icon: 'loading'
    })

    if (that.data.Total) {
      let x = that.data.letterNums + 20
      let old_data = that.data.key
      db.collection('Letter').orderBy('time', 'desc').skip(x) // 限制返回数量为 20 条
        .get()
        .then(res => {
          if (res.data.length == 0) {
            wx.showToast({
              title: '已经到底了',
              icon: 'none'
            })
          }
          // 利用concat函数连接新数据与旧数据并更新key 
          that.setData({
            key: old_data.concat(res.data),
            letterNums: x
          })
        })
        .catch(err => {
          console.error(err)
        })

    } else {
      let x = that.data.letterNums2 + 20
      let old_data = that.data.key
      db.collection('Letter').where({
          reading: _.gte(30) //此处根据阅读量过滤多余信件
        }).orderBy('time', 'desc').skip(x) // 限制返回数量为 20 条
        .get()
        .then(res => {
          if (res.data.length == 0) {
            wx.showToast({
              title: '已经到底了',
              icon: 'none'
            })
          }
          // 利用concat函数连接新数据与旧数据
          // 并更新emial_nums  
          that.setData({
            key: old_data.concat(res.data),
            letterNums2: x
          })
        })
        .catch(err => {
          console.error(err)
        })
    }


  },


  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  /**
   * 设置信封的收藏状态
   * @param {信封的搜索记录索引} choose 
   */
  setCollectStatus: function (choose) {
    var that = this
    db.collection('Collected').where({
      collecterId: that.data._openid,
      LetterId: that.data.key[choose]._id
    }).get({
      success: res => {

        var item = 'key[' + choose + '].like'
        var bool = (res.data.length != 0)
        //  console.log("boolvalue  "+bool)                      
        that.setData({
          [item]: bool
        }, function () { //setdata的回调函数

        })
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '收藏状态更新失败'
        })
        console.error('[数据库] [新增记录] 失败：', err)
        return choose
      }
    })
  }
})