const db = wx.cloud.database()
const _ = db.command
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userdata: "", //用来保存用户数据
    currentUserid: "" //当前用户的openid
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    var that = this

    db.collection('User').where({
      _openid: options.id
    }).get({
      success: res => {
        that.setData({
          userdata: res.data[0],
          ShowImage: app.globalData.ShowImage,
          currentUserid: options.id,
        })
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '用户信息查询失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
      }
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  /**
   * 打开或关闭他人可见
   */
  AllowTap: function (e) {
    var that = this
    that.setData({
      'userdata.Visible': !that.data.userdata.Visible
    })
    console.log(that.data.userdata.Visible)
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this
    that.setData({
      ShowImage: app.globalData.ShowImage
    })

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    var that = this
    wx.cloud.callFunction({
      name: "UpdateVisibleStatus",
      data: {
        _id: that.data.userdata._id,
        DBN: "User",
        fieldvalue: that.data.userdata.Visible
      },
      success: res => {
        console.log('公开状态更改成功')

      },
      fail: err => {
        console.log(that.data.key[HomeId]._id)
        console.log(err)
        console.log('公开状态更改失败')
        wx.navigateTo({
          url: 'home-detail/home-detail?id=' + that.data.key[HomeId]._id,
        })
      }
    })
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
})