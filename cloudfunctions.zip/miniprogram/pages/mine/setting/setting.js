const app = getApp()
Page({
  data: {
    theme: 'light',
    setting: {},
    ShowImage:true
  },
  onLoad: function (options) {
    var that = this
    that.setData({
      ShowImage:app.globalData.ShowImage
    })
  },
  onReady: function () {
    // 页面渲染完成
  },
  onShow: function () {
    // 页面显示
  },
  onHide: function () {
    // 页面隐藏
  },
  onUnload: function () {
    // 页面关闭
  },

  delDateLoad:function(){
    wx.clearStorageSync()
    wx.showToast({
      title: '下载数据清除完毕',
    })
  },
  /**
   * 控制图片显示
   * @param {} e 
   */
  ImageShowChange:function(e){
    app.globalData.ShowImage = !app.globalData.ShowImage
  }
});