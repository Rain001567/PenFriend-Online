const db = wx.cloud.database()
const _ = db.command
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ShowMessage: true, //true为代表正常显示信息，false代表显示搜索信息
    searchKey: "", //搜索关键字
    _openid: "",
    Message: [], //保存显示的信件
    SearchResult: [], //搜索结果
    i: 0,
    letterNums: 0, //信息加载跳过数（从数据库读取的开始位置）
    letterNums2: 0, //
    ID: "", //信件ID
    DBN: "Message", //页面数据来源数据库名称
    MessageType: 1 //当前正在浏览的信息类型
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    console.log("MessageDetail-onLoad执行")

    wx.cloud.callFunction({
      name: 'login',
      complete: res => {
        that.setData({
          _openid: res.result.openid,
          MessageType: options.id
        })
        console.log("MessageDetail-onLoad: that.data.MessageType = " + that.data.MessageType)


        db.collection(that.data.DBN).where({
          receiverId: that.data._openid,
          type: parseInt(that.data.MessageType) //这里要用int值传入，尚未知道原因,可能是数据类型问题
        }).get({
          success: res => {

            if (res.data.length !== 0) {
              that.setData({
                Message: res.data,

              }, () => {
                wx.showToast({
                  title: '信息加载完成,上划查看全部消息',
                  icon: 'none'
                })
              })
            } else {
              var word;
              if (options.id == 1) {
                word = "关注消息"
              } else if (options.id == 2) {
                word = "系统通知"
              } else {
                word = "已读消息"
              }
              wx.showToast({

                title: '目前未有任何' + word + '，返回信息页面',
                icon: 'none',
                duration: 2000,
                success: function () {
                  setTimeout(function () {
                    wx.navigateBack({
                      delta: 1
                    })
                  }, 2000);

                }
              })

            }

          }
        })
      }
    })

  },
  //保存搜索输入
  searchInput: function (e) {
    var that = this
    that.setData({
      searchKey: e.detail.value
    })
  },
  /**
   * 点击搜索按钮
   */
  onSearchClickTap: function () {
    var that = this
    // console.log(that.data.searchKey)
    if (that.data.searchKey == "") {
      wx.showToast({
        title: '请输入搜索词!',
        icon: 'none',
        duration: 1500
      })


    } else {

      wx.cloud.callFunction({
        name: "CountDataBaseRecoredNum",
        data: {
          dataBaseName: "Message"
        },

        success: res => {

          var batchTimes = Math.ceil(res.result.total / 20)
          var x = 0
          var result = []
          //初次循环获取云端数据库的分次数的promise数组
          for (let i = 0; i < batchTimes; i++) {
            db.collection(that.data.DBN).where(
              _.and([{
                  content: db.RegExp({
                    regexp: '.*' + that.data.searchKey,
                    options: 'i',
                  })
                },
                {
                  type: parseInt(that.data.MessageType)
                }
              ])
            ).orderBy('time', 'desc').skip(i * 20).get({

              success: res => {
                console.log(res.data.length)
                result = result.concat(res.data),
                  x++
                if (x == batchTimes) {
                  if (result.length != 0) {

                    that.setData({
                      SearchResult: result,
                      ShowMessage: false //代表此时显示搜索结果
                    }, () => {
                      wx.showToast({
                        title: '搜索完成',
                        icon: "success"
                      })
                    })
                  } else {
                    wx.showToast({
                      title: '未搜寻到相关信息，返回',
                      icon: 'none',
                      success: function () {
                        setTimeout(function () {
                          that.setData({
                            ShowMessage:true
                          })  
                        
                        }, 1500);
            
                      }
                    })

                  }
                }
              },
              fail: err => {
                console.log("message-获取信息搜索结果失败")
                console.log(err)
              }
            })
          }

        },
        fail: err => {
          wx.showToast({
            title: '查询信息数失败' + err,
            icon: null
          })

        }
      })
    }

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function (choose) {
    var that = this
    //   console.log("message-detail onshow zhixing")
    if (choose == 1) {
      db.collection(that.data.DBN).where({
        receiverId: that.data._openid,
        type: parseInt(that.data.MessageType) //这里要用int值传入，尚未知道原因,可能是数据类型问题
      }).get({
        success: res => {
          console.log(res)
          if (res.data.length !== 0) {
            that.setData({
              Message: res.data,

            }, () => {
              wx.showToast({
                title: '信息加载完成,上划查看全部消息',
                icon: 'none'
              })
            })
          } else {
            var word;
            if (that.data.MessageType == 1) {
              word = "关注消息"
            } else if (that.data.MessageType == 2) {
              word = "系统通知"
            } else {
              word = "已读消息"
            }
            wx.showToast({

              title: '目前未有任何' + word + '，返回信息页面',
              icon: 'none',
              duration: 2000,
              success: function () {
                setTimeout(function () {
                  wx.navigateBack({
                    delta: 2
                  })
                }, 2000);

              }
            })

          }

        }
      })
    }



  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    wx.showLoading({
      title: '刷新中！',
      duration: 1500
    })
    var that = this
    if (that.ShowMessage) {
      let x = that.data.letterNums + 20
      console.log('下次全部页面显示限制条数' + x)
      let old_data = that.data.key
      db.collection(that.data.DBN).where({
          type: parseInt(that.data.MessageType)
        }).skip(x) // 限制返回数量为 20 条
        .get()
        .then(res => {
          if (res.data.length == 0) {
            wx.showToast({
              title: '已经到底了',
              icon: 'none'
            })
          }
          // 利用concat函数连接新数据与旧数据
          // 并更新emial_nums  
          that.setData({
            Message: old_data.concat(res.data),
            letterNums: x
          })
          console.log(res.data)
        })
        .catch(err => {
          console.error(err)
        })

    }
    console.log('circle 下一页');

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  /**
   * 返回全部信息按钮
   */
  btn: function () {
    var that = this;
    that.setData({
      ShowMessage: true
    })
  },

  /**
   * 设置为已读
   */
  setAsRead: function (e) {
    var that = this
    wx.cloud.callFunction({
      name: "UpdateMessageStatus",
      data: {
        _id:e.currentTarget.id,
        DBN: that.data.DBN,
        fieldvalue: 3
      },
      success: res => {
        wx.showToast({
          title: '消息已保存至已读消息',
          icon:'none',
          success: function () {
            setTimeout(function () {
              console.log("MessageDetail-消息设置为已读成功")
              if (!that.data.ShowMessage) {
                that.onSearchClickTap()
                that.onShow()
              } else {

                that.onShow(1)
              }
            }, 1500);

          }
        })

      },
      fail: err => {
        console.log(that.data.key[HomeId]._id)
        console.log(err)
        console.log('信件状态更改失败')
      }
    })
  },

  /**
   * 删除消息
   */
  deleteMessage: function (e) {
    var that = this
    wx.cloud.callFunction({
      name: "remove",
      data: {
        _id: e.currentTarget.id,
        databaseName: that.data.DBN
      },
      success: res => {
        wx.showToast({
          title: '消息删除成功',
          icon:'none',
          success: function () {
            setTimeout(function () {
              console.log("MessageDetail-消息删除成功")
              if (!that.data.ShowMessage) {

                that.onSearchClickTap()
                that.onShow()
              } else {

                that.onShow(1)
              }
            }, 1500);

          }
        })
      },
      fail: err => {
        wx.showToast({
          title: '信息删除失败' + err,
        })
      }
    })
  }
})